import "../App.css";
import Todos from "./Todos";

function App() {
  return (
    <div className="App">
      <Todos />
    </div>
  );
}

export default App;
